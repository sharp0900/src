package com.mycompany.a2;

public interface IMoveable {
	public void move();
	
}
